<html>
<body>
<?php

$db_config['servername'] = "localhost";
$db_config['username'] = "ecollect_ctlquiz";
$db_config['password'] = "tnDuF![l3G)9";
$db_config['dbname'] = "ecollect_lumencppquiz";

?>
</body>
</html>