<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Lumen CPP Quiz</title>

<!-- Begin CSS -->
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/styles.css" rel="stylesheet">
</head>
<!-- End CSS -->

<body class="rules_back">
	<div class="container">
		<!-- Top color bar -->
		<div class="top-bar row">
			<div class="col-xs-2 bar-1"></div>
			<div class="col-xs-4 bar-2"></div>
			<div class="col-xs-6 bar-3"></div>
		</div>
		<div class="rules">
			<a href="#" onclick="javascript:window.open('','_self').close();">‹ Back to Quiz</a>
			<h2 class="rules-intro">LUMEN PARTNER VIRTUAL EVENT CONTEST OFFICIAL RULES</h2>
			<p>
				NO PURCHASE NECESSARY. VOID WHERE PROHIBITED. A PURCHASE WILL NOT INCREASE YOUR CHANCES OF WINNING.<br><br>

				<u><b>Sponsor.</b></u> CenturyTel Service Group, LLC (“Lumen” or “Sponsor”) <br><br>

				<u><b>Entry Period.</b></u> Lumen will host, or participate in, various Virtual Conference Events (“Event” or “Events”) throughout 2020 and 2021.  During those Events, Lumen may conduct a virtual contest (“Contest”) for qualifying, registered attendees.  The Entry Period will be defined by the Lumen representative conducting the Contest, at their discretion, during each applicable Event. <br><br>

				<u><b>Entry Conditions.</b></u> Entrant must be at least 18 years of age at the time of participation, a registered and participating attendee of the Event and who are legal residents of either one of the 48 continental states of the United States or the District of Columbia, including entry from one of those locations. This Contest is void in Alaska, Hawaii and Puerto Rico and/or where prohibited by law. Employees of Sponsor, any affiliate of Sponsor, any of their advertising or promotional agencies, any sponsor of any prize offered in this Contest or any business or entity involved in the development, production, implementation, administration or fulfillment of this Contest, and their immediate family members (meaning spouses, parents, siblings and children) or public employees (e.g., employed by state, local, or federal government or one of their agencies) are not eligible to enter or win. <br><br>

				<u><b>Entry.</b></u> Entrant must attend the Event and participate in the Event Quiz to potentially win a prize and receive an entry into the Grand Prize random drawing. <br><br>

				On-line entries will be declared made by the authorized account holder of the e-mail address/social media account (“account”) submitted at time of entry. “Authorized account holder” is defined as the natural person who is assigned to the account by an Internet access/social media provider, online service provider or other organization (e.g., business, educational, institution, etc.) responsible for assigning accounts for the domain associated with the submitted account. Lumen is not responsible for late, lost, misdirected, mis-delivered, incomplete, incorrect, inaccurate or unintelligible entries, messages, typographical errors, unavailable network connections, failed, incomplete, garbled, or delayed computer transmissions, on-line failures, hardware, software, servers, providers, equipment, human error or other technical malfunctions or disturbances or any other communications failures or circumstances affecting, disrupting or corrupting the Contest in any manner. Lumen also is not responsible for any damages to Entrant’s computer/device occasioned by participation in the Contest or by downloading any information or data necessary to participate in the Contest. If for any reason the Sponsor is not capable of running the Contest as planned due to, among other factors, any technical failure or corruptions of any kind, the Sponsor reserves the right to cancel, modify or suspend the Contest and select winners from eligible entries received prior to cancellation. The Entrant may be required to provide Sponsor with confirmation that he/she is the authorized account holder of the account. <br><br>

				All completed entries become the property of Lumen and will not be returned. Entries without all of the blanks completed will be disqualified and not entered into the Contest. All late, lost, or incomplete entries are not considered valid entries. Any form of entry other than as specified in these rules (including but not limited to automated, copied, third-party or mechanically reproduced entries) is prohibited and will be disqualified. Sponsor will be collecting personal data about Entrants when they register and enter the Contest. Please review Lumen’s privacy policy at www.Lumen.com. By participating in the Contest, entrants agree to all of the terms and conditions of the privacy policies of the Sponsor. By entering, Entrant agrees to be bound by these official rules and the decisions of the Sponsor which will be final and binding in all respects. The official rules will be posted at the Contest website throughout the Contest. <br><br>

				If Entrant participates in the Event via a wireless device, Sponsor is not responsible for any charges from the wireless phone provider made to the Entrant and Entrant agrees to incur any and all charges demanded by their wireless carrier. Entrant should also check their device's features for capabilities and check the device manual for specific use instructions. <br><br>

				<u><b>Prize.</b></u> There are two ways to potentially win a prize.  Entrants who answer five questions correctly will receive one entry into the Grand Prize random drawing.  Entrants who answer the bonus question correctly will receive one entry into the Grand Prize random drawing.  Entrants who answer all five questions correctly and the bonus question correctly will receive two total entries into the Grand Prize random drawing. Entrants who do not participate or answer any questions correctly will not receive a prize or entry into the drawing. <br><br>

				<u>Part 1:  Answer Event Quiz Questions</u> <br><br>

				<b>If Entrant answers one to three questions correctly</b>, they can choose a prize, from predetermined prizes selected by Lumen, valued up to $9.75. <br><br>

				<b>If Entrant answers four questions correctly</b>, they can choose a prize, from predetermined prizes selected by Lumen, valued up to $13.50. <br><br>

				<b>If Entrant answers all five questions correctly</b>, they can choose a prize, from predetermined prizes selected by Lumen, valued up to $43.75. Also, answering all five questions allows one entry into the Grand Prize random drawing. <br><br>

				<u>Part 2:  Grand Prize Random Drawing</u> <br><br>

				The Grand Prize, valued at up to $119.00, will be pre-selected by the Lumen representative conducting the Contest and at their discretion.  The Grand Prize may vary by Event. One Grand Prize will be awarded to one winner per Event.

				<ul>
				<li>Lumen does not provide service, maintenance, warranty, or replace any lost, broken, or stolen Prize.</li>
				<li>All manufacturers of Prizes are not sponsors, or endorsers, of the Contest.</li>
				<li>Listed Prize does not include any services or other related or incidental expenses.</li>
				</ul>

				<b>Total Contest Prize Value is dependent on the number of qualifying Entrants and their participation, number of questions answered correctly, prize selected by each qualifying Entrant and one Grand Prize value per Event.</b>
				<br><br>

				Prize is not transferable. Sponsor will have the right to substitute another prize package of equal or greater value, at its sole discretion. Sponsor may substitute a cash prize or goods or services with a value equal to or greater than the estimated retail value of the original prize. Winner will not have the right to substitute another prize package. Any difference between the stated approximate retail value of any prize and the actual value of such prize will not be awarded. All expenses not specified, including but not limited to taxes, fees, surcharges, from the acceptance or use of the prize are the sole responsibility of the winner(s). Any unclaimed prize will not be awarded. <br><br>

				<u><b>Grand Prize Winner Selection and Notification.</b></u> A random drawing of all qualifying entries will be conducted after the Event Quiz is administered/completed, the day of the Event, by an authorized Lumen representative whose decision will be final. The winner will be notified by email or phone number provided at registration. In the event the person originally selected as the winner is disqualified or does not respond within 5 days, the prize will be given to a second winner chosen via a random drawing of the remaining entries, conducted within 5 days of such disqualification. <br><br>

				<u><b>Odds.</b></u> Odds of winning a prize is dependent on the number of Entrants and the number of questions that are answered correctly. <br><br>

				<u><b>Prize Acceptance.</b></u> Grand Prize Winner must complete, execute and return the Lumen Affidavit of Eligibility, Liability and Publicity Release confirming the winner’s identification and eligibility. If such documents are not executed at the time of Contest or if any winner is found to be ineligible or not in compliance with these official rules, disqualification may result. This Contest is void where prohibited or restricted. No transfer or cash redemption of prize is permitted except at the sole discretion of the Sponsors, who may substitute a prize of equal or greater value if the advertised prize becomes unavailable. Limit one prize per household or family. All prizes will be mailed to Entrants and Grand Prize Winner at the residential address provided at the time of entry. <br><br>

				<u><b>Taxation.</b></u> Winners are solely responsible for any and all federal, state, and local income taxes associated with his or her Prize. Sponsor is not responsible for and will not pay or in any way compensate Winners for taxes associated with winning a Prize in this Contest. The Winner may be required to provide certain tax related documents to Lumen before receiving a prize. If required by law, Lumen will issue Form 1099-MISC to Winner reporting the taxable retail value of his or her Prize. The Winner should consult his or her tax advisor about the tax implications of winning a Prize. <br><br>

				<u><b>General Conditions.</b></u> By entering, Entrants agree (a) to these Official Rules and the decisions of the Sponsor, which shall be final in all matters relating to the Contest; (b) to release and hold harmless Sponsor and all affiliated companies and directors, officers and employees from any and all claims, liability or damages arising out of their participation in the Contest and the acceptance and use of a prize; (c) to permit Sponsor and its agents to use Prize recipients’ name, city and/or likeness for advertising, promotional and publicity purposes in all media without additional compensation and any prior review or approval; (d) that under no circumstances will Entrant be permitted to obtain awards for, and Entrant hereby waives all rights to claim punitive, incidental, consequential or any other damages, other than for actual out-of-pocket expenses; and (e) that all causes of action arising out of or connected with this Contest, or any prizes awarded, shall be resolved individually, without resort to any form class action. <br><br>

				<u><b>Governing Law.</b></u> Contest will be governed by and construed in accordance with the laws of the State of Louisiana. <br><br>

				<u><b>Winner’s Name and Official Rules.</b></u> All inquiries concerning the Contest including, but not limited to, a copy of the official rules or the winner’s name may be directed to: patti.walkenhorst@Lumen.com. <br><br>

				Winner’s Name and Official Rules. All inquiries concerning the Contest including, but not limited to, a copy of the official rules or the winner’s name may be directed to: patti.walkenhorst@Lumen.com. </p>

				<p class="border-top buffer-bottom">In accordance with Federal law, contact Lumen Customer Service to add your contact information to the Lumen Do Not Mail and/or Do Not Call lists if you do not wish to receive any sweepstakes or contest information (process may take up to two weeks).</p>
		</div>
	</div>

	<!-- Begin JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/script.js"></script>
    <!-- End JavaScript -->

</body>
</html>