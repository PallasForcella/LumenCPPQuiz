<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Lumen CPP Quiz</title>

	<!-- CSS -->
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link href="assets/styles.css" rel="stylesheet">
</head>

<body>
	<div class="container">
		<!-- Color bar and logo -->
		<div class="top-bar row">
			
		</div>
		<div class="logo">
			<img src="assets/image/logo-lumen.png">
		</div>
		<!-- Welcome screen -->
		<div class="screen" id="screen_1">
			<p class="intro">Offering flexible solutions for your prospects and customers</p>
			<h3 class="headline">Do you call yourself a techie? Let's see what you know!</h3>
			<div class="row">
				<div class="col-sm-4 tv">
					<img src="assets/image/amazon-echo-show.png">
				</div>
				<div class="col-sm-1"></div>
				<div class="col-sm-7">
					<p>
						Test your tech knowledge by answering five "simple" questions. Earn a prize selection based on your total number of correct answers. In addition, answer all five correctly and you'll be entered into a drawing for a premium prize valued at over $100.
					</p>
					<p class="fine-print buffered">
						No purchase necessary to enter or win. Void where prohibited. Up to 2 entries per individual. Must be 18 years of age to enter. Entry period begins 11/17/20 at 0:00 a.m. EST and ends on 11/18/20 at 2:00 p.m. EST. For complete rules see <a href="rules.php" target="_blank">www.lumencppquiz.com/rules</a>
					</p>
					<button class="btn btn-primary pull-right" onclick="changeScreen(1,2,'-150%')">Quiz Me!</button>
				</div>
			</div>
			<p class="desktop-only"><br>
				For the best experience, we recommend using the current version of Chrome, Microsoft Edge, Firefox, or Safari. Internet Explorer may not function correctly
			</p>
			<div class="row bordered">
				<span style="width:auto">Our Channel Partners help drive our success. <a href="https://www.lumen.com/en-us/partner.html" target="_blank">Learn more about the Lumen Channel Partner Program.</a></span>
			</div>
		</div>
		<!-- Question 1 -->
		<div class="screen secondary-screen" id="screen_2">
			<p class="intro">Question 1 of 5</p>
			<h3 class="headline">How many global route miles of fiber does Lumen have across its network?</h3>
			<div>
				<input type="radio" name="1" value="a" hidden>
				<button id="1a" class="btn btn-primary btn_1 zoomable" onclick="select('1','a')">A. 50,000</button>
			</div>
			<div>
				<input type="radio" name="1" value="b" hidden>
				<button id="1b" class="btn btn-primary btn_1 zoomable" onclick="select('1','b')">B. 100,000</button>
			</div>
			<div>
				<input type="radio" name="1" value="c" hidden>
				<button id="1c" class="btn btn-primary btn_1 zoomable" onclick="select('1','c')">C. 250,000</button>
			</div>
			<div>
				<input type="radio" name="1" value="d" hidden>
				<button id="1d" class="btn btn-primary btn_1 zoomable" onclick="select('1','d')">D. 450,000</button>
			</div>
			<div class="row" id="answer_1" hidden>
				<div class="answer">
					<p class="intro" id="answer_1_response_wrong" hidden><span style="color:#0075C9">Yes, that’s right.</span></p>
					<p class="intro" id="answer_1_response_right" hidden><span style="color:#0075C9">Oh, no, that’s not correct.</span></p>
					<p class="intro">The answer is: D</p>
					<p>As the second-largest U.S. communications provider to global enterprise companies, Lumen’s powerful and expansive global network spans approximately 450,000 global route miles of fiber with more than 150,000 on-net buildings.</p>
				</div>
				<button class="btn btn-primary pull-right" class="btn-next" onclick="changeScreen(2,3,'-150%')">Next Question ›</button>
			</div>

		</div>
		<!-- Question 2 -->
		<div class="screen secondary-screen" id="screen_3">
			<p class="intro">Question 2 of 5</p>
			<h3 class="headline">How many cybersecurity threats are monitored daily on the Lumen network?</h3>
			<div>
				<input type="radio" name="2" value="a" hidden>
				<button id="2a" class="btn btn-primary btn_2 zoomable" onclick="select('2','a')">A. 570,000</button>
			</div>
			<div>
				<input type="radio" name="2" value="b" hidden>
				<button id="2b" class="btn btn-primary btn_2 zoomable" onclick="select('2','b')">B. 1.4 million</button>
			</div>
			<div>
				<input type="radio" name="2" value="c" hidden>
				<button id="2c" class="btn btn-primary btn_2 zoomable" onclick="select('2','c')">C. 2.1 million</button>
			</div>
			<div>
				<input type="radio" name="2" value="d" hidden>
				<button id="2d" class="btn btn-primary btn_2 zoomable" onclick="select('2','d')">D. 3.6 million</button>
			</div>
			<div class="row" id="answer_2" hidden>
				<div class="answer">
					<p class="intro" id="answer_2_response_wrong" hidden><span style="color:#0075C9">You are correct!</span></p>
					<p class="intro" id="answer_2_response_right" hidden><span style="color:#0075C9">No, sorry, that’s not right</span></p>
					<p class="intro">The answer is: D</p>
					<p>Lumen’s threat research arm, Black Lotus Labs, analyzes 190 billion NetFlow sessions and over 3.6 million security events every day.</p>
				</div>
				<button class="btn btn-primary pull-right zoomable" class="btn-next" onclick="changeScreen(3,4,'-150%')">Next Question ›</button>
			</div>

		</div>
		<!-- Question 3 -->
		<div class="screen secondary-screen" id="screen_4">
			<p class="intro">Question 3 of 5</p>
			<h3 class="headline">Enterprises that choose a single UC&C provider have experienced a reduction in OpEx of up to:</h3>
			<div>
				<input type="radio" name="3" value="a" hidden>
				<button id="3a" class="btn btn-primary btn_3 zoomable" onclick="select('3','a')">A. 36%</button>
			</div>
			<div>
				<input type="radio" name="3" value="b" hidden>
				<button id="3b" class="btn btn-primary btn_3 zoomable" onclick="select('3','b')">B. 26%</button>
			</div>
			<div>
				<input type="radio" name="3" value="c" hidden>
				<button id="3c" class="btn btn-primary btn_3 zoomable" onclick="select('3','c')">C. 16%</button>
			</div>
			<div>
				<input type="radio" name="3" value="d" hidden>
				<button id="3d" class="btn btn-primary btn_3" onclick="select('3','d')">D. 6%</button>
			</div>
			<div class="row" id="answer_3" hidden>
				<div class="answer">
					<p class="intro" id="answer_3_response_wrong" hidden><span style="color:#0075C9">Yes! Who doesn’t like reducing costs.</span></p>
					<p class="intro" id="answer_3_response_right" hidden><span style="color:#0075C9">Oh, no, that’s not correct.</span></p>
					<p class="intro">The answer is: B</p>
					<p>New UC&C capabilities are rich with possibilities for efficiency, future readiness, and predictable costs. But the complex migration to these empowering technologies requires an experienced provider.* Wherever you are in your journey, Lumen can help you make the right choices simply, cost-effectively, and at your own pace.<br><br>
					*Nemertes. (2020, April). 2020 Customer and Employee Experience Study.</p>
				</div>
				<button class="btn btn-primary pull-right" class="btn-next" onclick="changeScreen(4,5,'-150%')">Next Question ›</button>
			</div>

		</div>
		<!-- Question 4 -->
		<div class="screen secondary-screen" id="screen_5">
			<p class="intro">Question 4 of 5</p>
			<h3 class="headline">Lumen’s cloud Edge Computing nodes are designed to meet 98% of the U.S. enterprise demand within how many milliseconds of latency?</h3>
			<div>
				<input type="radio" name="4" value="a" hidden>
				<button id="4a" class="btn btn-primary btn_4" onclick="select('4','a')">A. 2 milliseconds</button>
			</div>
			<div>
				<input type="radio" name="4" value="b" hidden>
				<button id="4b" class="btn btn-primary btn_4" onclick="select('4','b')">B. 5 milliseconds</button>
			</div>
			<div>
				<input type="radio" name="4" value="c" hidden>
				<button id="4c" class="btn btn-primary btn_4" onclick="select('4','c')">C. 8 milliseconds</button>
			</div>
			<div>
				<input type="radio" name="4" value="d" hidden>
				<button id="4d" class="btn btn-primary btn_4" onclick="select('4','d')">D. 10 milliseconds</button>
			</div>
			<div class="row" id="answer_4" hidden>
				<div class="answer">
					<p class="intro" id="answer_4_response_wrong" hidden><span style="color:#0075C9">Great job!</span></p>
					<p class="intro" id="answer_4_response_right" hidden><span style="color:#0075C9">No, sorry, it's 5ms!</span></p>
					<p class="intro">The answer is: B</p>
					<p>Lumen’s cloud Edge Computing nodes are designed to meet 98% of the U.S. enterprise demand within 5ms of latency.</p>
				</div>
				<button class="btn btn-primary pull-right" class="btn-next" onclick="changeScreen(5,6,'-150%')">Next Question ›</button>
			</div>

		</div>
		<!-- Question 5 -->
		<div class="screen secondary-screen" id="screen_6">
			<p class="intro">Question 5 of 5</p>
			<h3 class="headline">True or False? Lumen’s Partner Incentives are stackable, and a Partner can earn multiple payouts on one opportunity.</h3>
			<div>
				<input type="radio" name="5" value="a" hidden>
				<button id="5a" class="btn btn-primary btn_5" onclick="select('5','a')">True</button>
			</div>
			<div>
				<input type="radio" name="5" value="b" hidden>
				<button id="5b" class="btn btn-primary btn_5" onclick="select('5','b')">False</button>
			</div>
			<div class="row" id="answer_5" hidden>
				<div class="answer">
					<p class="intro" id="answer_5_response_wrong" hidden><span style="color:#0075C9">You know your stuff! This is true!</span></p>
					<p class="intro" id="answer_5_response_right" hidden><span style="color:#0075C9">No, sorry, it is true.</span></p>
					<p>True! All of Lumen’s Partner Incentives are stackable, meaning a Partner may be eligible for more than one payout if their opportunity qualifies for more than one incentive. For full incentive details, contact your Channel Manager or email <a href="mailto:partners@lumen.com">partners@lumen.com</a></p>
				</div>
				<button class="btn btn-primary pull-right" class="btn-next" onclick="changeScreen(6,7,'-150%')">Next ›</button>
			</div>

		</div>
		<!-- Prize selections -->
		<div class="screen secondary-screen" id="screen_7">
			
			<h3 class="headline">Congratulations!</h3>
			<h3 id="quiz_grade"></h3>
			<div class="please-select" class="headline">Please select one of these prize options.</div>
			<div class="row" id="prize_level_1" hidden>
				<div class="col-sm-4 prize-container">
					<div class="row"><p class="prize-title">A Mobile Phone’s Companions</p></div>
					<div class="row"><img class="prize-image" src="assets/image/1-prize-1.png"></div>
					<div class="row"><button id="Auto_Pop_Car_Charger" class="btn btn-primary zoomable prize-btn" onclick="setPrize(this.id)">Select</button></div>
				</div>
				<div class="row mobile-divider"></div>
				<div class="col-sm-4 prize-container">
					<div class="row"><p class="prize-title">Tumbler of Tchotchkes</p></div>
					<div class="row"><img class="prize-image" src="assets/image/1-prize-2.png"></div>
					<div class="row"><button id="CenturyLink_Prize_Pack" class="btn btn-primary zoomable prize-btn" onclick="setPrize(this.id)">Select</button></div>
				</div>
				<div class="row mobile-divider"></div>
				<div class="col-sm-4 prize-container">
					<div class="row"><p class="prize-title">Golfer’s Companions</p></div>
					<div class="row"><img class="prize-image" src="assets/image/1-prize-3.png"></div>
					<div class="row"><button id="Wireless_Car_Mouse" class="btn btn-primary zoomable prize-btn" onclick="setPrize(this.id)">Select</button></div>
				</div>
			</div>
			<div class="row" id="prize_level_2" hidden>
				<div class="col-sm-4 prize-container">
					<div class="row"><p class="prize-title">Thor Copper Vacuum Insulated Tumbler</p></div>
					<div class="row"><img class="prize-image" src="assets/image/2-prize-1.png"></div>
					<div class="row"><button id="Boxanne_Wireless_Speaker" class="btn btn-primary zoomable prize-btn" onclick="setPrize(this.id)">Select</button></div>
				</div>
				<div class="row mobile-divider"></div>
				<div class="col-sm-4 prize-container">
					<div class="row"><p class="prize-title">Thor Copper Vacuum Insulated Bottle</p></div>
					<div class="row"><img class="prize-image" src="assets/image/2-prize-2.png"></div>
					<div class="row"><button id="Anker_PowerWave_Charger" class="btn btn-primary prize-btn" onclick="setPrize(this.id)">Select</button></div>
				</div>
				<div class="row mobile-divider"></div>
				<div class="col-sm-4 prize-container">
					<div class="row"><p class="prize-title">Lumen Desk Set</p></div>
					<div class="row"><img class="prize-image" src="assets/image/2-prize-3.png"></div>
					<div class="row"><button id="Atom_Wireless_Earbud" class="btn btn-primary prize-btn" onclick="setPrize(this.id)">Select</button></div>
				</div>
			</div>
			<div class="row" id="prize_level_3" hidden>
				<div class="row">
					<div class="col-sm-4 prize-container">
						<div class="row"><p class="prize-title">Wireless Ergonomics Optical Mouse & Aluminum Mouse Pad combo</p></div>
						<div class="row"><img class="prize-image" src="assets/image/3-prize-1.png"></div>
						<div class="row"><button id="Life_in_Motion_Padfolio" class="btn btn-primary prize-btn" onclick="setPrize(this.id)">Select</button></div>
					</div>
					<div class="row mobile-divider"></div>
					<div class="col-sm-4 prize-container">
						<div class="row"><p class="prize-title">Aircharge Plus Universal Power Bank with Wireless Charging</p></div>
						<div class="row"><img class="prize-image" src="assets/image/3-prize-2.png"></div>
						<div class="row"><button id="Ivy_Mini_Printer" class="btn btn-primary prize-btn" onclick="setPrize(this.id)">Select</button></div>
					</div>
					<div class="row mobile-divider"></div>
					<div class="col-sm-4 prize-container">
						<div class="row"><p class="prize-title">Igloo Maddox XL Cooler</p></div>
						<div class="row"><img class="prize-image" src="assets/image/3-prize-3.png"></div>
						<div class="row"><button id="WiFi_Selfie_Drone" class="btn btn-primary prize-btn" onclick="setPrize(this.id)">Select</button></div>
					</div>
				</div>
			</div>

		</div>
		<!-- User info screen -->
		<div class="screen secondary-screen" id="screen_8">
			
			<h3>Thanks for your selection.</h3>
			<p>Please fill out the form so we know where to send your prize.</p>
			<form id="user_form">
				<div class="row form-top">
					Partner prize form
				</div>
				<div class="row">
					<div class="col col-sm-12">
						<label>Prize selection:</label>
						<input class="form-control" type="text" id="prize" name="prize" readonly style="background-color: white;" onclick="changeScreen(8,7,'150%')">
					</div>
				</div>
				<div class="row">
					<div class="col col-sm-5">
						<label>*First Name:</label>
						<input class="form-control" type="text" name="firstname" placeholder="John" required>
					</div>
					<div class="col col-sm-7">
						<label>*Last Name:</label>
						<input class="form-control" type="text" name="lastname" placeholder="Smith" required>
					</div>
				</div>
				<div class="row">
					<div class="col col-sm-12">
						<label>*Mailing Address 1:</label>
						<input class="form-control" type="text" name="address1" placeholder="123 Street Name" required>
					</div>
				</div>
				<div class="row">
					<div class="col col-sm-12">
						<label>Mailing Address 2:</label>
						<input class="form-control" type="text" name="address2" placeholder="Suite No 2">
					</div>
				</div>
				<div class="row desktop-only">
					<div class="col col-sm-5">
						<label>*City:</label>
						<input class="form-control" type="text" id="city_desktop" name="city" placeholder="Johnstown" required>
					</div>
					<div class="col col-sm-2">
						<label>*State:</label>
						<select class="form-control" type="text" id="state_desktop" name="state" required>
							<option value=""></option>
						</select>
					</div>
					<div class="col col-sm-5">
						<label>*Zip Code:</label>
						<input class="form-control" type="text" id="zipcode_desktop" name="zipcode" placeholder="12345" required>
					</div>
				</div>
				<div class="row mobile-only">
					<div class="col col-sm-12">
						<label>*City:</label>
						<input class="form-control" type="text" id="city_mobile" name="city" placeholder="Johnstown" required>
					</div>
				</div>
				<div class="row mobile-only">
					<div class="col col-xs-4">
						<label>*State:</label>
						<select class="form-control" type="text" id="state_mobile" name="state" required>
							<option value=""></option>
						</select>
					</div>
					<div class="col col-xs-8">
						<label>*Zip Code:</label>
						<input class="form-control" type="text" id="zipcode_mobile" name="zipcode" placeholder="12345" required>
					</div>
				</div>
				<div class="row">
					<div class="col col-sm-4">
						<label>*Phone:</label>
						<input class="form-control" type="text" name="phone" placeholder="719-123-4567" required>
					</div>
					<div class="col col-sm-8">
						<label>Email:</label>
						<input class="form-control" type="email" name="email" placeholder="smith@company.com">
					</div>
				</div>
				<button class="btn btn-primary pull-right submit-btn" type="button" onclick="changeScreen(8,9,'-150%')">Submit</button>
				<input type="hidden" id="drawing" name="drawing" value="0">
			</form>
	
		</div>
		<!-- Bonus question -->
		<div class="screen secondary-screen" id="screen_9">
			<h3 class="headline">Thanks! Would you like to answer a bonus question for an entry into a random prize drawing?</h3>
			<div class="bonus-header">
				<div class="row">
					<div class="col-xs-12 mobile-only">
						Get the correct answer and be entered into a random drawing to win a premium prize.
					</div>
					<div class="col-xs-8 desktop-only">
						Get the correct answer and be entered into a random drawing to win a premium prize.
					</div>
					<div class="col-xs-4 desktop-only bonus-image">
						<img src="assets/image/bonus.png">
					</div>
				</div>
			</div>
			<div class="bonus-main">
				<h3 class="bonus">At an average pace, how many days would it take you to walk the Lumen fiber network (assuming it could be walked)?</h3>
				<div class="bonus-buttons">
					<div>
						<input type="radio" name="6" value="a" hidden>
						<button id="6a" class="btn btn-primary btn_6 zoomable" onclick="select('6','a')">A. 1,000 days</button>
					</div>
					<div>
						<input type="radio" name="6" value="b" hidden>
						<button id="6b" class="btn btn-primary btn_6 zoomable" onclick="select('6','b')">B. 2,500 days</button>
					</div>
					<div>
						<input type="radio" name="6" value="c" hidden>
						<button id="6c" class="btn btn-primary btn_6 zoomable" onclick="select('6','c')">C. 3,650 days</button>
					</div>
					<div>
						<input type="radio" name="6" value="d" hidden>
						<button id="6d" class="btn btn-primary btn_6 zoomable" onclick="select('6','d')">D. 6,250 days</button>
					</div>
				</div>
			</div>
			<div class="row" id="answer_6" hidden>
				<div class="answer">
					<p class="intro" id="answer_6_response_wrong" hidden><span style="color:#0075C9">Yes, that’s right! You've earned an entry into the random drawing to win a premium prize</span></p>
					<p class="intro" id="answer_6_response_right" hidden><span style="color:#0075C9">Oh, no, that's not correct. Thanks for playing!</span></p>
					<p class="intro">The answer is: D</p>
					<p>6,250 DAYS! Walking at an average page of 20 minutes per mile, it would take 6,250 days to walk 450,000 miles!</p>
				</div>
				<button class="btn btn-primary pull-right" onclick="changeScreen(9,10,'-150%')">Finish</button>
			</div>

		</div>
		<!-- Thank you page -->
		<div class="screen secondary-screen" id="screen_10">
			<h3>Thank you for visiting our booth and participating in our quiz!</h3>
			<p id="delivery">Your prize will be mailed to the address you provided in 2 - 3 weeks.</p>
			<p id="drawing_msg"></p>
			<p>Please reach out to <a href="mailto: partners@lumen.com" target="_blank">partners@lumen.com</a> for more information on the Lumen Partner Program, or visit <a href="https://www.lumen.com/en-us/partner.html" target="_blank">lumen.com/en-us/partner.html</a></p>
			<h3>You can now close this quiz page.</h3>

		</div>
		<!-- Footer -->
		<div class="footer">
			<p class="footer-rules" class="footer">© 2020 Lumen Technologies. All Rights Reserved. Third party marks are the property of their respective owners. For complete rules, see </span><a href="rules.php" target="_blank">https://lumencppquiz.com/rules</a></p>
			<a class="footer-learn" class="footer" href="mailto: partners@lumen.com" target="_blank">
			Want to learn more? Email us now
		</a>
		</div>
	</div>

	<!-- JavaScript -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/jquery.validate.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/script.js"></script>

</body>
</html>